@extends('back-end.layout.app')
@section('content')

<div style="position: fixed; top: 0; left: 0; height: 95%; width: 100%">
    <iframe src="http://awfrlk.net/public/chatify/public/chatify" frameborder="0" width="80%" height="100%">

    </iframe>
</div>
@endsection