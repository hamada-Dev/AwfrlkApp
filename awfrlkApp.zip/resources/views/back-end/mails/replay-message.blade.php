Dear <h5 style="display: inline-block">{{$oldMessage->name}}</h5>,
<br>


I hope my email find you will , <br>

{{$replay}} .

<br>
Best Regards
