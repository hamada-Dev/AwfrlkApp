<footer class="footer text-center" style="position: relative; bottom: 0;">
    <div class="container-fluid">
        <div class="copyright float-right">
           
             All rights reserved.&copy;
            <script>
                document.write(new Date().getFullYear())
            </script><a href="https://vintagetechnology.info"><strong style="color: yellow">Vintage Technology</strong> </a>

        </div>
        <!-- your footer here -->
    </div>
</footer>
