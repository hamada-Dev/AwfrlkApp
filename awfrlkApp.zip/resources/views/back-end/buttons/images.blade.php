<a href="{{route($module_name_plural.'.images', $row)}}" rel="tooltip" title="" class="btn btn-white btn-link btn-sm" data-original-title=" @lang('site.images')">
    <i class="material-icons">photo_library</i>
</a>
